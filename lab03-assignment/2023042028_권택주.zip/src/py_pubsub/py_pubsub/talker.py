def main():
    print('Hi from py_pubsub.')


if __name__ == '__main__':
    main()
